package com.example.activitat_04

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import java.util.*

class StartActivity : AppCompatActivity() {

    private lateinit var userName: String
    private var correctNumber: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)

        // Obtener el nombre de usuario
        userName = intent.getStringExtra("EXTRA_NAME") ?: "Usuario"

        // Generar número correcto aleatorio
        correctNumber = Random().nextInt(3) + 1

        setupUI()
    }

    private fun setupUI() {
        val tvUserName = findViewById<TextView>(R.id.tvUserName)
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroup)
        val btnGuess = findViewById<AppCompatButton>(R.id.btnGuess)
        val btnBack = findViewById<AppCompatButton>(R.id.btnBack)

        tvUserName.text = "Hola, $userName"

        btnGuess.setOnClickListener {
            val selectedId = radioGroup.checkedRadioButtonId

            if (selectedId == -1) {
                Toast.makeText(this, "Por favor, selecciona un número", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val selectedRadioButton = findViewById<RadioButton>(selectedId)
            val selectedNumber = selectedRadioButton.text.toString().toInt()

            // Determinar a qué actividad ir
            val intent = if (selectedNumber == correctNumber) {
                Intent(this, SuccessActivity::class.java)
            } else {
                Intent(this, ErrorActivity::class.java)
            }

            // Pasar datos
            intent.putExtra("USER_NAME", userName)
            intent.putExtra("SELECTED_NUMBER", selectedNumber)
            intent.putExtra("CORRECT_NUMBER", correctNumber)

            startActivity(intent)
        }

        btnBack.setOnClickListener {
            finish()
        }
    }
}