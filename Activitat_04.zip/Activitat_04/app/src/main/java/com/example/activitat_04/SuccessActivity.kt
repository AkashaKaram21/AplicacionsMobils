package com.example.activitat_04

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton

class SuccessActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_success)

        // Obtener datos
        val userName = intent.getStringExtra("USER_NAME") ?: "Usuario"
        val selectedNumber = intent.getIntExtra("SELECTED_NUMBER", 0)
        val correctNumber = intent.getIntExtra("CORRECT_NUMBER", 0)

        setupUI(userName, selectedNumber, correctNumber)
    }

    private fun setupUI(userName: String, selectedNumber: Int, correctNumber: Int) {
        val tvUserInfo = findViewById<TextView>(R.id.tvUserInfo)
        val tvNumberInfo = findViewById<TextView>(R.id.tvNumberInfo)
        val btnBack = findViewById<AppCompatButton>(R.id.btnBack)

        tvUserInfo.text = "Usuario: $userName"
        tvNumberInfo.text = "Número seleccionado: $selectedNumber\nNúmero correcto: $correctNumber"

        btnBack.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            startActivity(intent)
            finish()
        }
    }
}